package Logica;

import Logica.Entidades.*;

import javax.swing.*;
import java.time.Year;
import java.util.*;

public class Datos {
    static Random rand = new Random();

    // Array de nombres de países ficticios
    static String[] nombresPaises = {"Argentina", "Chile", "Francia", "Italia", "España", "Estados Unidos"};


    // Array de nombres de provicias
    static String[] nombresProvincias = {"Buenos Aires", "Catamarca", "Chaco", "Chubut", "Córdoba", "Corrientes",
            "Entre Ríos", "Formosa", "Jujuy", "La Pampa", "La Rioja", "Mendoza", "Misiones", "Neuquén",
            "Río Negro", "Salta", "San Juan", "San Luis", "Santa Cruz", "Santa Fe", "Santiago del Estero",
            "Tierra del Fuego", "Tucumán"};

    // Array de nombres de bodegas
    static String[] nombresBodegas = {
            "Liam", "Olivia", "Noah", "Emma", "William",
            "Ava", "James", "Isabella", "Oliver", "Sophia",
            "Benjamin", "Mia", "Elijah", "Charlotte", "Lucas",
            "Amelia", "Mason", "Harper", "Logan", "Evelyn"
    };

    static String[] nombresVinos = {
            "Gran Reserva Malbec", "Chardonnay del Valle", "Cabernet Sauvignon Supremo",
            "Sauvignon Blanc Selecto", "Merlot Vintage", "Pinot Noir Exquisito",
            "Rosado Primavera", "Syrah de la Casa", "Riesling Dulce",
            "Tempranillo Clásico", "Garnacha Reserva", "Prosecco Burbujeante",
            "Zinfandel Festivo", "Moscato Floral", "Shiraz Intenso",
            "Cabernet Franc Noble", "Verdejo Fresco", "Malvasía Aromática",
            "Sangiovese Toscano", "Gewürztraminer Exótico", "Chianti Tradicional",
            "Chenin Blanc Delicado", "Nebbiolo Majestuoso", "Carmenere Fino",
            "Grüner Veltliner Fresco", "Malbec Argentino", "Viognier Seductor",
            "Nero d'Avola Robust", "Albariño Atlántico", "Bonarda Jugoso",
            "Pinot Grigio Refrescante", "Tannat Elegante", "Barolo Imperial",
            "Cava Espumoso", "Grenache Fruity", "Lambrusco Dolce",
            "Petit Verdot Único", "Ribera del Duero Reserva", "Vinho Verde Fresco",
            "Touriga Nacional Exclusivo", "Bordeaux Blend", "Sancerre Blanco",
            "Côtes du Rhône", "Valpolicella Classico", "Rioja Gran Reserva",
            "Priorat Singular", "Fiano Aromático", "Aglianico Poderoso",
            "Marsanne Sedosa", "Torrontés Aromático"
    };

    static String[] reseniasVinos = {
            "Malbec robusto con notas a ciruela y chocolate negro.",
            "Chardonnay fresco y afrutado, perfecto para una tarde de verano.",
            "Cabernet Sauvignon intenso con aromas a cassis y vainilla.",
            "Sauvignon Blanc refrescante con toques cítricos y herbales.",
            "Merlot suave con sabores a frutos rojos maduros.",
            "Pinot Noir elegante con notas a cereza y tierra húmeda.",
            "Rosado ligero y floral, ideal para un picnic en el campo.",
            "Syrah especiado con matices a pimienta negra y moras.",
            "Riesling semidulce con aromas a melocotón y miel.",
            "Tempranillo estructurado con toques a vainilla y regaliz.",
            "Garnacha fresca con sabores a frutas del bosque y especias.",
            "Prosecco burbujeante con notas a pera y manzana verde.",
            "Zinfandel afrutado con toques a fresa y canela.",
            "Moscato dulce y refrescante con aromas a flor de azahar.",
            "Shiraz potente con sabores a mora y chocolate.",
            "Cabernet Franc elegante con matices a pimiento verde y grosella.",
            "Verdejo vibrante con toques a hierba recién cortada y cítricos.",
            "Malvasía seductora con notas a albaricoque y jazmín.",
            "Sangiovese terroso con aromas a cereza y tabaco.",
            "Gewürztraminer exótico con sabores a lichi y jengibre.",
            "Chianti clásico con taninos firmes y notas a cereza ácida.",
            "Chenin Blanc fresco con toques a pera y miel.",
            "Nebbiolo complejo con matices a rosa marchita y cuero.",
            "Carmenere especiado con notas a pimiento rojo y mora.",
            "Grüner Veltliner con acidez refrescante y aromas a lima y pimienta blanca.",
            "Malbec argentino con carácter frutal y suave textura.",
            "Viognier seductor con aromas a albaricoque y flor de azahar.",
            "Nero d'Avola con cuerpo y sabores a cereza negra y chocolate.",
            "Albariño atlántico con notas a melocotón y salinidad.",
            "Bonarda jugoso con toques a frutas del bosque y vainilla."
    };

    static String[] nombresRegiones = {"Norte","Sur","Este", "Oeste", "Noreste", "Sureste", "Noroeste", "Suroeste"};

    public static List<Pais> obtenerPaises () {
        List<Pais> paises = new ArrayList<>();
        for (int j = 0; j < 5; j++) {
            //int numPaisAleatorio = rand.nextInt(nombresPaises.length);
            // String paisAleatorio = nombresPaises[numPaisAleatorio];
            Pais pais = new Pais();
            pais.setNombre(nombresPaises[j]);
            paises.add(pais);
        }
        return paises;
    }
    public static List<Provincia> obtenerProvincias(Pais pais) {
        List<Provincia> provincias = new ArrayList<>();
        for (int i = 0; i < 8; i++) { // Suponiendo que hay 5 provincias por país
            Provincia provincia = new Provincia();
            int numProviciaAletoria = rand.nextInt(nombresProvincias.length);
            provincia.setNombre(nombresProvincias[numProviciaAletoria]);
            provincia.setPais(pais);
            provincias.add(provincia);
        }
        return provincias;
    }

    public static List<RegionVitivinicola> obtenerRegiones (Provincia provincia) {
        // Lista de regiones vitivinícolas ficticias para esta provincia
        List<RegionVitivinicola> regiones = new ArrayList<>();
        for (int j = 0; j < nombresRegiones.length; j++) {
            int numRegionAleatoria = rand.nextInt(nombresRegiones.length);
            String regionAleatoria = nombresRegiones[numRegionAleatoria];
            RegionVitivinicola region = new RegionVitivinicola(provincia, regionAleatoria, "Descripción de la región");
            regiones.add(region);
        }
        return regiones;
    }
    //Cambie array de fechas por array list
    public static List<Date> crearFechas() {
        //CREAR FECHAS (antes estaba adentro de bodegas)
        List<Date> fechas = new ArrayList<>();

        // Obtener la fecha actual
        Date fechaActual = new Date();

        // Crear 20 fechas utilizando un ciclo for
        for (int j = 0; j < 20; j++) {
            // Calcular la fecha sumando el número de días al momento actual
            long tiempo = fechaActual.getTime() + j * 24L * 60 * 60 * 1000; // 24 horas * 60 minutos * 60 segundos * 1000 milisegundos
            Date fecha = new Date(tiempo);
            fechas.add(fecha);
        }
        return fechas;
    }

    //Cambie array de bodegas por un array list.
    //BODEGAS

    public static List<Bodega> crearBodegas (List<Date> fechas, List<Pais> paises) {
        List<Bodega> bodegas = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            List <Double> coordenadas = new ArrayList();
            double latitud = Math.random()*100;
            double longitud = Math.random()*100;

            // Poner latitud y longitud a dos decimales
            String formattedLatitud = String.format(Locale.ENGLISH,"%.2f", latitud);
            String formattedLongitud = String.format(Locale.ENGLISH,"%.2f", longitud);

            // Convertir los valores de vuelta a double
            latitud = Double.parseDouble(formattedLatitud);
            longitud = Double.parseDouble(formattedLongitud);

            coordenadas.add(latitud);
            coordenadas.add(longitud);

            String descripcion = "Descripicon Bodega: " + i;
            String historia = "Historia de bodega: " + i;

            Date periodoActualizacion = fechas.get(rand.nextInt(fechas.size()));
            //Numero aleatorio para paises, provincia y region
            int numPaisBodega = rand.nextInt(paises.size());
            Pais paisSeleccionado = paises.get(numPaisBodega);
            int numProvinciaBodega = rand.nextInt(paisSeleccionado.getProvincias().size());
            Provincia provinciaSeleccionada = paisSeleccionado.getProvincias().get(numProvinciaBodega);
            int numRegionBodega = rand.nextInt(provinciaSeleccionada.getRegiones().size());
            RegionVitivinicola regionSeleccionada = provinciaSeleccionada.getRegiones().get(numRegionBodega);

            // Generar un índice aleatorio dentro del rango de la lista de nombres
            int numNombresBodegasAleatorio = rand.nextInt(nombresBodegas.length);

            // Seleccionar el nombre aleatorio usando el índice generado
            String nombreAleatorio = nombresBodegas[numNombresBodegasAleatorio];

            Bodega bodega = new Bodega();
            bodega.setRegion(regionSeleccionada);
            bodega.setCoordenadas(coordenadas);
            bodega.setDescripcion(descripcion);
            bodega.setHistoria(historia);
            bodega.setNombre(nombreAleatorio);
            bodega.setPeriodoActualizacion(periodoActualizacion);
            bodegas.add(bodega);
        }
        return bodegas;
    }
    //VARIETAL
    public static List<Varietal> crearVarietales () {
        List<Varietal> varietales = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            float porcentajeVarietal = rand.nextInt(100) ;
            Varietal varietal = new Varietal("Descripcion " + (i+1), porcentajeVarietal);
            varietales.add(varietal);
        }
        return varietales;
    }

    //VINOS
    public static List<Vino> crearVinos (List<Varietal> varietales, List<Bodega> bodegas) {
        // Crear lista de vinos
        List<Vino> vinos = new ArrayList<>();

        // Crear 20 instancias de Vino y agregarlas a la lista
        for (int i = 0; i < 20; i++) {
            Vino vino = new Vino();
            int anioAleatorio = rand.nextInt(2024 - 1000 + 1) + 1000; //Año aleatorio entre 1000 y 2024
            Year anioVino = Year.of(anioAleatorio);//Lo transformo a tipo de dato año
            vino.setAñada(anioVino); // Cambiar el año según sea necesario
            vino.setImagenEtiqueta(new ImageIcon("../images/wine-vector-1.png")); // Cambiar la ruta de la imagen según sea necesario
            vino.setNotaDeCataBodega("Nota de cata " + (i + 1));
            //Un precio base de 5000 y a eso le sumo el contador por 10
            vino.setPrecioARS(5000.0f + (i*10));

            //Nombrar vino aleatoriamente
            int numNombreVino = rand.nextInt(nombresVinos.length);
            String nombreVinoAleatorio = nombresVinos[numNombreVino];
            vino.setNombre(nombreVinoAleatorio);

            // Asignar una bodega aleatoria al vino
            int numBodegaAleatorio = rand.nextInt(bodegas.size());
            Bodega bodegaSeleccionada = bodegas.get(numBodegaAleatorio);
            vino.setBodega(bodegaSeleccionada);

            // Agregar varietales al vino según sea necesario. Que tenga de 1 a 3 varietales
            int cantVarietal = rand.nextInt(3) + 1;
            List<Varietal> varietalesSeleccionados = new ArrayList<>();
            for (int j = 0; j < cantVarietal; j++) {
                int varietalSeleccionado = rand.nextInt(20);
                varietalesSeleccionados.add(varietales.get(varietalSeleccionado));
            }
            vino.setVarietal(varietalesSeleccionados);

            // Agregar vino a la lista de vinos
            vinos.add(vino);
        }
        return vinos;
    }

    //RESEÑA
    public static List<Reseña> crearReseñas (Vino vino) {
        // Crear 20 objetos de la clase Reseña
        List<Reseña> reseñas = new ArrayList<>();

        //Entre 1 y 10 reseñas para cada vino
        int cantReseñas = rand.nextInt(10) + 1;
        for (int i = 0; i < cantReseñas; i++) {
            List<Date> fechasReseñas = crearFechas();
            int numFechAleatoria = rand.nextInt(fechasReseñas.size());
            Date fechaReseña = fechasReseñas.get(numFechAleatoria);

            //No recuerdo si dice que el puntaje es de 1 a 10.
            int puntos = rand.nextInt(10) + 1;

            //Obtengo un numero 0 o 1, para obtener un booleano aleatorio para saber si es premium
            int numeroParaPremium = rand.nextInt(2);
            boolean booleanoPremium = numeroParaPremium == 1;

            int numComentarioAleatorio = rand.nextInt(reseniasVinos.length);
            String comentarioSelecccionado = reseniasVinos[numComentarioAleatorio];
            Reseña reseña = new Reseña(comentarioSelecccionado, booleanoPremium, fechaReseña, puntos , vino);

            reseñas.add(reseña);
        }
        return reseñas;
    }
}
