package Logica;

import Boundaries.PantallaPrincipal;
import Boundaries.PantallaRankingVinos;
import Logica.Entidades.*;

import javax.swing.ImageIcon;
import java.util.Date;
import java.util.List;

public class Principal {

    public static void main(String[] args) {
        

        /*
        
         // Instancia de Prueba de la Pantalla de Ranking Vinos...
        PantallaRankingVinos pantallaRankingVinos = new PantallaRankingVinos();
        
        
        // Título de la Ventana...
        
        pantallaRankingVinos.setTitle("Generar Ranking de Vinos");
        
        // Permite que la ventana sea visible...
        
        pantallaRankingVinos.setVisible(true);
        
        // Permite que la ventana se quede fija en el centro...
        
        pantallaRankingVinos.setLocationRelativeTo(null);
        
        // Evita que se pueda maximizar la ventana, ésto lo podemos tratar después, para que no se rompa el código
        
        pantallaRankingVinos.setResizable(false);
        
        */
        
        /*
        
        Pantalla Principal
        
        
        */
        
        PantallaPrincipal pantallaPrincipal = new PantallaPrincipal();
        
        pantallaPrincipal.setTitle("BonVino");
        
        // Permite que la ventana sea visible...
        
        pantallaPrincipal.setVisible(true);
        
        // Permite que la ventana se quede fija en el centro...
        
        pantallaPrincipal.setLocationRelativeTo(null);
        
        // Evita que se pueda maximizar la ventana, ésto lo podemos tratar después, para que no se rompa el código
        
        pantallaPrincipal.setResizable(false);


        //======================================================================
        //INCORPORO CREACION DE DATOS
        List<Pais> paises = Datos.obtenerPaises();
        // Asignar provincias a cada país
        for (Pais pais : paises) {
            List<Provincia> provincias = Datos.obtenerProvincias(pais);
            pais.setProvincias(provincias);

            // Asignar regiones a cada provincia
            for (Provincia provincia : provincias) {
                List<RegionVitivinicola> regiones = Datos.obtenerRegiones(provincia);
                provincia.setRegiones(regiones);
            }
        }

        //Hasta aca ya tenemos todos los paises con sus provincias y cons sus regiones
        //cada pais tiene 8 provincias y cada provincia tiene 8 regiones

        //Creamos una lista de fechas: 20 elementos
        List<Date> fechas = Datos.crearFechas();

        //Creamos una lista de bodegas: 20 elementos
        List<Bodega> bodegas1 = Datos.crearBodegas(fechas, paises);

        //Creamos una lista de varietales: 20 elementos
        List<Varietal> varietales1 = Datos.crearVarietales();

        //Creamos una lista de vinos pasandole de parametro la lista de bodegas y de varietales.
        //De toda la lista el vino a tener de 1 a 3 varietales y una bodega
        List<Vino> vinos = Datos.crearVinos(varietales1, bodegas1);

        // Asignar reseñas a cada vino.
        //Cada reseña tenia su vino pero el vino no todas su reseñas
        for (Vino vino : vinos) {
            //se van creadno las reseñas de un vino
            List<Reseña> reseñas = Datos.crearReseñas(vino);
            //Asigno esas reseñas a su correspondiente vino
            vino.setReseñas(reseñas);
        }

        System.out.println("DATOS DE BODEGAS");
        System.out.println("NOMBRE BODDEGA: " +bodegas1.get(1).getNombre());
        System.out.println("FECHA ACTUALIZACION: " + bodegas1.get(1).getPeriodoActualizacion());
        System.out.println("DESCRIPCION: " + bodegas1.get(1).getDescripcion());
        System.out.println("HISTORIA: " +bodegas1.get(1).getHistoria());
        System.out.println("REGION: " +bodegas1.get(1).getRegion().getNombre());
        System.out.println("PROVINCIA: " + bodegas1.get(1).getRegion().getProvincia().getNombre());
        System.out.println("PAIS: " + bodegas1.get(1).getRegion().getProvincia().getPais().getNombre());
        System.out.println("COORDENADAS: " +bodegas1.get(1).getCoordenadas());

        System.out.println("------------------------------------------------");
        System.out.println("NOMBRE BODDEGA: " +bodegas1.get(2).getNombre());
        System.out.println("FECHA ACTUALIZACION: " + bodegas1.get(2).getPeriodoActualizacion());
        System.out.println("DESCRIPCION: " + bodegas1.get(2).getDescripcion());
        System.out.println("HISTORIA: " + bodegas1.get(2).getHistoria());
        System.out.println("REGION: " + bodegas1.get(2).getRegion().getNombre());
        System.out.println("PROVINCIA: " + bodegas1.get(2).getRegion().getProvincia().getNombre());
        System.out.println("PAIS: " + bodegas1.get(2).getRegion().getProvincia().getPais().getNombre());
        System.out.println("COORDENADAS: " +bodegas1.get(2).getCoordenadas());

        System.out.println("------------------------------------------------");
        System.out.println("NOMBRE BODDEGA: " +bodegas1.get(18).getNombre());
        System.out.println("FECHA ACTUALIZACION: " + bodegas1.get(18).getPeriodoActualizacion());
        System.out.println("DESCRIPCION: " + bodegas1.get(18).getDescripcion());
        System.out.println("HISTORIA: " + bodegas1.get(18).getHistoria());
        System.out.println("REGION: " + bodegas1.get(18).getRegion().getNombre());
        System.out.println("PROVINCIA: " + bodegas1.get(18).getRegion().getProvincia().getNombre());
        System.out.println("PAIS: " + bodegas1.get(18).getRegion().getProvincia().getPais().getNombre());
        System.out.println("COORDENADAS: " +bodegas1.get(18).getCoordenadas());



        //MOSTRANDO DATOS VINOS
        Vino vino2 = vinos.get(2);
        Vino vino0 = vinos.get(0);

        System.out.println();
        System.out.println("DATOS DE VINOS");
        System.out.println("Cantidad de Vinos: " + vinos.size());

        System.out.println("Año: " + vino0.getAñada());
        System.out.println("Nombre: " + vino0.getNombre());
        System.out.println("Varietales: " + vino0.getVarietal()); //Muestro la lista de varietales (se va a ver los punteros)
        System.out.println("Nota de Cata: " + vino0.getNotaDeCataBodega());
        System.out.println("Precio: $" + vino0.getPrecioARS());
        //No me carga la imagen
        System.out.println("Imagen:" + vino0.getImagenEtiqueta());
        System.out.println("Bodega:" + vino0.getBodega().getNombre());
        System.out.println("VARIETAL:" + vino0.getVarietal());
        System.out.println("Reseñas:" + vino0.getReseñas());

        System.out.println("_______________________________________________");

        System.out.println("Año: " + vino2.getAñada());
        System.out.println("Nombre: " + vino2.getNombre());
        System.out.println("Varietales: " + vino2.getVarietal()); //Muestro la lista de varietales (se va a ver los punteros)
        System.out.println("Nota de Cata: " + vino2.getNotaDeCataBodega());
        System.out.println("Precio: $" + vino2.getPrecioARS());
        //No me carga la imagen
        System.out.println("Imagen:" + vino2.getImagenEtiqueta());
        System.out.println("Bodega:" + vino2.getBodega().getNombre());
        System.out.println("VARIETAL:" + vino2.getVarietal());
        System.out.println("Reseñas:" + vino2.getReseñas());

        //MOSTRANDO DATOS DE UNA RESEÑA
        List<Reseña> reseñasDeVino0 = vino0.getReseñas();
        System.out.println();
        System.out.println("DATOS DE RESEÑA");
        System.out.println("Cantidad de Reseñas: " + reseñasDeVino0.size());
        System.out.println("Comentario: " + reseñasDeVino0.get(0).getComentario());
        System.out.println("Fecha: " + reseñasDeVino0.get(0).getFechaReseña());
        System.out.println("Puntaje: " + reseñasDeVino0.get(0).getPuntaje());
        System.out.println("Vino: " + reseñasDeVino0.get(0).getVino().getNombre());
        System.out.println("Es comentario premium: " + reseñasDeVino0.get(0).getEsPremium());
        System.out.println("Es de un somelier: " + reseñasDeVino0.get(0).sosDeSommelier());
        //Para esto deberiamos formatear la fecha de alguna forma.
        //System.out.println("Es de un somelier: " + reseña1.esFechaEnPeriodo());

        System.out.println();
        System.out.println("_______________________________________________");
        System.out.println();
        System.out.println("Comentario: " + reseñasDeVino0.get(1).getComentario());
        System.out.println("Fecha: " + reseñasDeVino0.get(1).getFechaReseña());
        System.out.println("Puntaje: " + reseñasDeVino0.get(1).getPuntaje());
        System.out.println("Vino: " + reseñasDeVino0.get(1).getVino().getNombre());
        System.out.println("Es comentario premium: " + reseñasDeVino0.get(1).getEsPremium());
        System.out.println("Es de un somelier: " + reseñasDeVino0.get(1).sosDeSommelier());
        System.out.println("Es de fecha en periodo " + reseñasDeVino0.get(1).esFechaEnPeriodo("10/02/2003","25/12/2024"));


        
        
    }
}
